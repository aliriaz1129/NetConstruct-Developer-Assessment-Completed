﻿
using NetC.JuniorDeveloperExam.Web.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using System.Web.Hosting;

namespace NetC.JuniorDeveloperExam.Web.Controllers
{

    public class BlogController : Controller
    {
        private List<BlogPost> blogPosts;

        public BlogController()
        {
            // Initialize blogPosts with an empty list
            blogPosts = new List<BlogPost>();
        }

        // Create a method to load the blog posts from the JSON file
        private void LoadBlogPosts()
        {
            // Get the JSON file path using MapPath
            string jsonFilePath = Server.MapPath("~/App_Data/Blog-Posts.json");

            if (System.IO.File.Exists(jsonFilePath))
            {
                using (StreamReader sr = new StreamReader(jsonFilePath))
                {
                    string json = sr.ReadToEnd();
                    var blogData = JsonConvert.DeserializeObject<BlogData>(json);
                    blogPosts = blogData.blogPosts;
                }
            }
            else
            {
                // Handle the case where the file doesn't exist
            }
        }


        // Action to display a list of blog posts
        public ActionResult Index()
        {
            // Load the blog posts if they haven't been loaded yet
            if (blogPosts == null || blogPosts.Count == 0)
            {
                LoadBlogPosts();
            }
            var blogData = new BlogData { blogPosts = blogPosts };
            return View("Index", blogData);
        }

        // Action to display a specific blog post based on its ID
        public ActionResult Show(int? id)
        {
            // Load the blog posts if they haven't been loaded yet
            if (blogPosts == null || blogPosts.Count == 0)
            {
                LoadBlogPosts();
            }

            BlogPost blogPost = blogPosts.FirstOrDefault(post => post.Id == id);

            if (blogPost == null)
            {
                return HttpNotFound();
            }

            return View("BlogPost", blogPost);
        }

        // Action to comment
        [HttpPost]
        public ActionResult AddComment(int id, Comment comment)
        {
            // Load the blog posts if they haven't been loaded yet
            if (blogPosts == null || blogPosts.Count == 0)
            {
                LoadBlogPosts();
            }

            BlogPost blogPost = blogPosts.FirstOrDefault(post => post.Id == id);

            if (blogPost == null)
            {
                return HttpNotFound();
            }
            if (blogPost.Comments == null)
            {
                blogPost.Comments = new List<Comment>();
            }

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var error in errors)
                {
                    // Log or print error message
                    Debug.WriteLine(error.ErrorMessage);
                }
            }
            else
            {
                
                comment.Date = DateTime.Now;

                comment.Name = Request.Form["Comments[0].Name"];
                comment.EmailAddress = Request.Form["Comments[0].EmailAddress"];
                comment.Message = Request.Form["Comments[0].Message"];

                
                blogPost.Comments.Add(comment);

                // save the updated data back to the JSON file
                SaveBlogPosts();

                // Redirect to the "Show" action to display the updated blog post
                return RedirectToAction("Show", new { id = id });
            }

            // If ModelState is not valid, return to the same view
            return View("BlogPost", blogPost);
        }
        // Action to add a reply
        [HttpPost]
        public ActionResult AddReply(int postId, int commentId, Reply reply)
        {
            // Load the blog posts if they haven't been loaded yet
            if (blogPosts == null || blogPosts.Count == 0)
            {
                LoadBlogPosts();
            }

            BlogPost blogPost = blogPosts.FirstOrDefault(post => post.Id == postId);

            if (blogPost == null)
            {
                return HttpNotFound();
            }

            Comment parentComment = blogPost.Comments.FirstOrDefault(comment => comment.Id == commentId);

            if (parentComment == null)
            {
                return HttpNotFound();
            }

            if (parentComment.Replies == null)
            {
                parentComment.Replies = new List<Reply>();
            }

            if (!ModelState.IsValid)
    {
        // Handle validation errors
        var errors = ModelState.Values.SelectMany(v => v.Errors);
        foreach (var error in errors)
        {
            // Log or print error message
            Debug.WriteLine(error.ErrorMessage);
        }
    }
    else
    {
            reply.Date = DateTime.Now;
       
            reply.Name = Request.Form["comment.Replies[0].Name"];

            reply.EmailAddress = Request.Form["comment.Replies[0].EmailAddress"];
     
            reply.Message = Request.Form["comment.Replies[0].Message"];

                // Set the ParentCommentId
                reply.ParentCommentId = parentComment.Id;

                parentComment.Replies.Add(reply);

                // Save the updated data back to the JSON file
                SaveBlogPosts();

                // Redirect back to the "Show" action to display the updated blog post
                return RedirectToAction("Show", new { id = postId });
            }

            // If ModelState is not valid, return to the same view
            return View("BlogPost", blogPost);
        }




        private void SaveBlogPosts()
        {
            string jsonFilePath = Server.MapPath("~/App_Data/Blog-Posts.json");
            var blogData = new BlogData { blogPosts = blogPosts };

     
            string json = JsonConvert.SerializeObject(blogData, Formatting.Indented);
            System.IO.File.WriteAllText(jsonFilePath, json);
        }

    }


}
