﻿using System.Web.Mvc;
using System.Web.Routing;

namespace NetC.JuniorDeveloperExam.Web
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
   name: "AddReply",
   url: "blog/addreply/{postId}/{commentId}",
   defaults: new { controller = "Blog", action = "AddReply" }
);


            routes.MapRoute(
                name: "BlogPost",
                url: "blog/{id}",
                defaults: new { controller = "Blog", action = "Show" }
            );

            // Default route
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Blog", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
